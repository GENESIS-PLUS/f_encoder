<?php
$testpass = "NeWPaSS12345!"; //Enter your password or string you want to encode (use only Numbers, Сapital letters, Lowercase letters, Special characters: ! ? # _ @ - $ + % = )
$testsecret = "https://f-encoder.com/"; //Enter your secret code (any text)
$testalphabet = "yvW+JlS=15?B4-frOY3PxL7H#pqzRV!@aMUc_tEs6bgQCkFKGionmITDAd9jwe08h%X2uNZ$"; //Copy from the site https://f-encoder.com/ and replace the standard alphabet for unique encryption!

$encode = Fencoder\Encoder::process($testpass, $testsecret, $testalphabet); //Encode password
echo "Protected compressed password: <b>".$encode."</b></br>";

echo "Decrypted password: <b>".Fencoder\Decoder::process($encode, $testsecret, $testalphabet)."</b>"; //Decode password
?>